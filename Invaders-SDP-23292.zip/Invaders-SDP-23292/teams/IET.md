# IET

## Team Introduction

Hello

- **Team leader**
  - LU WENCHAO
- **Team members**
  - LU WENCHAO
  - QIN XIAOXIANG
  - WANG JUNBO
  - DENGTAO
  - ZHU ZHIHAO
  - BI SHAOYU
  - LIN SHENGHUI

## Team Requirements

- Our team needs to develop a visual effects system.
## Detailed Requirements

-1. May be bound to background music
2. Some visual effects and HUDs are displayed, while the other three will be gradually refined during compilation.