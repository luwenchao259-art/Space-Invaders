# Team KWAK
## Team Introduction

- Team Leader
    - `Kwak Gyeonggyu`
- Git Manager 
    - `Lee Jupil`
- Team member
    - `Kim Minjun`
    - `Choi Hunseok`
    - `Kim Minsub`
    - `Lee Jaehoo`
    - `Park Gisu`
## Team Requirements
### - Item System
## Detailed Requirements
- 1. Acquisition (Contact Range)
- 2. Drop (probability-based, specific mobs)
- 3. Movement (straight line, speed)
- 4. Activation (instant or key input)
- 5. Types:
Offensive: Multi-Shot, Attack Speed Increase, Penetration, Explosion
Defensive: Enemy Movement (Slow, Stop, Retreat), Shield (Use or Duration), Trench (Create or Repair), and Recovery. 
## Team Dependencies
- 1. Ship variety - Slow Item, Attack Item, etc.
- 2. Level design - Initialization or maintain  if Stage is finished
- 3. Gameplay HUD - Item description
- 4. Visual effects system - Item effect 