Team introduction:

Our team “Records & Achivement System” is mostly focusing of implementing achievements implementation and its variations 

Team Requirements:

We calculate each action executed from the user and calculate the score to set the final record. Our team is mainly responsible of tracking user’s action and calculate the total score.

Detailed Requirements:

Computing score from the user.

Track the progress of each achivement

Display message when a task is completed

Create new achievements button on the main screen

Alter file management system

Dependencies on Other Teams:

 - Gameplay HUD's graphical illustration
 - Player & Enemy Ship Variety: Needs to know the details of their work (e.g., enemy types) for achievement conditions, such as destroying specific enemies.
