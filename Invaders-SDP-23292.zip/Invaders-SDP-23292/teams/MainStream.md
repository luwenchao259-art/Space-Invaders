# MainStream
## Team Introduction
Hello
- Team Leader
    - `Wooseung Son`
- Development
    - `Hanbin Kim`
    - `Yeonhoo Seo`
    - `Hyesung Son`
    - `Junghyun Ahn`
    - `Dongchan Lee`
    - `Hohyeon Lee`
## Team Requirements
### - Main Menu : Develop buttons to be used in the game 
## Detailed Requirements
- Develop a button for achievements
- Develop BGM on/off button
## Dependencies on Other Teams
- Develop play mode(1 or 2 player) select button
- Implement pause in game
- Visual effect when we select a button