# Instructors
## Team Introduction
Hello
- Lecturer
    - `Scott UK-Jin Lee`
- Teaching Assistants
    - `Joonwoo Lee`
    - `Seungho Kim`
## Team Requirements
### - Instruct
## Detailed Requirements
- Lecture
- Lab